# Team Planner (static)

Single-page app (HTML/CSS/JS) using Supabase as backend.

## Setup (Supabase)
1. Create a Supabase project
2. Create 3 tables (Public schema):
   - `teams`
     - `id` BIGINT (primary key)
     - `name` TEXT
     - `description` TEXT
     - `color` TEXT
   - `members`
     - `id` BIGINT (primary key)
     - `name` TEXT
     - `role` TEXT
     - `email` TEXT
     - `team_id` BIGINT (nullable, FK -> teams.id)
   - `tasks`
     - `id` BIGINT (primary key)
     - `title` TEXT
     - `description` TEXT
     - `assignee` TEXT
     - `priority` TEXT
     - `status` TEXT
     - `deadline` DATE or TEXT (the app sends a date string)

3. Realtime:
   - Make sure Realtime is enabled for these tables (Database -> Replication / Realtime, depending on UI)

4. RLS (important):
   - If you want it to work from the browser, you must create RLS policies that allow **anon/publishable** access
   - For a quick internal tool: allow SELECT/INSERT/DELETE on these 3 tables for anon
   - If you need real security: add auth and write proper policies.

## Configure keys
Open `index.html` and replace:

- `SUPABASE_URL`
- `SUPABASE_KEY` (use **anon/public** or **publishable** key, NEVER the secret key)

## Run locally
Just open `index.html` in a local server (recommended):
- VS Code Live Server, or
- `python -m http.server 8000`

Then go to http://localhost:8000

## Deploy on GitHub Pages
- Push this repo to GitHub
- Settings -> Pages -> Deploy from branch -> `/ (root)`
